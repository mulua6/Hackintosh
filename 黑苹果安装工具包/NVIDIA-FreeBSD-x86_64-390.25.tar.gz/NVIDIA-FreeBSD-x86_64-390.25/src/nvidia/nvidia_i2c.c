#include "nv-misc.h"
#include "os-interface.h"
#include "nv.h"

void* NV_API_CALL nv_i2c_add_adapter(nv_state_t *nv, NvU32 port)
{
    return FALSE;
}

BOOL NV_API_CALL nv_i2c_del_adapter(nv_state_t *nv, void *data)
{
    return NULL;
}
